// common.js
document.addEventListener('DOMContentLoaded', function () {
    const body = document.body;
    const csSection = document.querySelector('.cs');

    // Check if the user has a preferred theme and set it
    if (localStorage.getItem("theme") === "dark") {
        enableDarkMode();
    }

    function enableDarkMode() {
        body.classList.add("dark-mode");
        csSection.style.background = "#121212"; // Set the background color for cs section in dark mode
        // Save the user's preference to localStorage
        localStorage.setItem("theme", "dark");
    }

    function enableGradientMode() {
        body.classList.remove("dark-mode");
        csSection.style.background = "linear-gradient(245.59deg, #6ca7d5 0%, #4e8cbf 28.53%, #7b2583 75.52%)";
        // Save the user's preference to localStorage
        localStorage.setItem("theme", "light");
    }

    window.enableDarkMode = enableDarkMode;
    window.enableGradientMode = enableGradientMode;
});
